import { Router } from 'express';
import { createShow, listShows } from '../controllers/show.controller.js';
import isLoggedIn from '../middlewares/authentication.js';
import authorizedRoles from '../middlewares/authorization.js';

const router = Router();

router.post('/', isLoggedIn, authorizedRoles('ADMIN'),  createShow);
router.get('/list', listShows);

export default router;