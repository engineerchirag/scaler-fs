// Ace interviews

// Q1: 

console.log(x); // A1:
var x = 5;

// Q2:
var x;
console.log(x); // A2:
x = 5;

// Q3:

hello();

function hello() {
    console.log('hello'); // A3.1
}

x = 10;
console.log(x); // A3.2
var x;

// Q4:

hello();
const hello = function() {
    console.log('hello'); // A4
}

hello1();
var hello1 = function() {
    console.log('hello'); // A4
}

// Q5: 

console.log(y); // A5
let y = 10;

// Q6:

z = 10;
console.log(z);
let z;