// var bodyRef = document.querySelector('body');
// console.log(bodyRef.innerText);

// var spanRef = document.createElement('span');
// spanRef.innerText = 'Script3 Location';
// bodyRef.appendChild(spanRef);

console.log(4);